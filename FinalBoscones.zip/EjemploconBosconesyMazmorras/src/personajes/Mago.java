package personajes;
/**
 * 
 * 
 * @author Yafar
 * @version 1.0
 */
public class Mago {

	//ATRIBUTOS
	
	private String nombre;
	private int vitalidad;
	private int agilidad;
	private int fuerza;

	
	//CONSTRUCTORES
	
	public Mago() {
		
	}
	
	public Mago(String nombre, int fuerza, int vitalidad, int agilidad) {
		
		this.nombre = nombre;
		this.vitalidad = vitalidad;
		this.agilidad = agilidad;
		this.fuerza = fuerza;
	}

	//GETTINGS AND SETTINGS
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getVitalidad() {
		return vitalidad;
	}

	public void setVitalidad(int vitalidad) {
		this.vitalidad = vitalidad;
	}

	public int getAgilidad() {
		return agilidad;
	}

	public void setAgilidad(int agilidad) {
		this.agilidad = agilidad;
	}

	public int getFuerza() {
		return fuerza;
	}

	public void setFuerza(int fuerza) {
		this.fuerza = fuerza;
	}
	
	//METODOS
	
	//He considerado que primero en el tablero se elije el ataque, entonces se tira dado de ataque y de esquiva, y esto es lo que se le
	//pasa al m�todo, el m�todo segun esto devuelve el ataque con su da�o y su cura o sino devuelve da�o 0 y en ambos casos un SYSO.
	
	/**
	 * 
	 * @param ataque Booleano que recibe para realizar el ataque
	 * @param esquiva 
	 * @param vit
	 * @return
	 */
	
	public int drenarVit(boolean ataque, boolean esquiva, int vit){
		//Ataque es el tiro para acertar y esquiva para esquivar.
		int da�o=0;
		int vitdanyo=0;
		
		vitdanyo=10;
		if (ataque==true && esquiva==false ) {	
			if(vit<this.vitalidad){
				vit=vit+vitdanyo;
				this.vitalidad=vit;
				
			}
			System.out.println("�Has drenado a tu enemigo!");
			da�o=15;
			
		}else{
		System.out.println("El drenaje ha fallado.");	
		
		
		}
		return da�o;
	}
	
	public int electrocutarEnemigo(boolean ataque, boolean esquiva){
		int da�o=0;
		if (ataque==true && esquiva==false) {
			System.out.println("!Has lanzado un rayo exterminador a tu enemigo!");
			da�o=30;
			
		}else{
			System.out.println("Electro ha fallado.");
			
		}
		return da�o;
	}
	
	
	public void mostrarDatosPersonaje() {
		System.out.println("Eres "+this.nombre+", un hechicero con "+
				((20-this.fuerza)*10)
				+ " de fuerza, con "+this.vitalidad+" de vitalidad y "+((20-this.agilidad)*10)+" de agilidad"
				);
	}
	public void mostrarAtaques(){
		System.out.println("\n\t1- Drenar");
		System.out.println("\t2- Electro");
		System.out.println("\t3- Usar Pocion");
		System.out.println("\t4- Sismo\n");
		
	}
	/**Metodo para recibir da�o
	 * 
	 * @param danyo
	 * @return vitalidad Devuelve la vitalidad tras 
	 */
	public int recibirDanyo(int danyo) {

		this.vitalidad = this.vitalidad - danyo;

		System.out.printf("Ha recibido %d de da�o. Su vitalidad es"
				+ " de %d VIT\n", danyo, this.vitalidad);

		return this.vitalidad;
	}
	public int realizarSismo(boolean ataque, boolean esquiva, boolean esp) {
		int res = 0;
		
		if(esp==true){
		
		if (ataque == true && esquiva == false ) {
			res = 40;
			System.out.println("�Super Espadazo!\n");

			esp=false;	
		}else{
			System.out.println("El ataque ha fallado");
		}
		}else{
			System.out.println("Solo puedes usar el Super Espadazo una vez por partida.");
		}
		return res;
	}
	public int usarPocion(int vitalidad, int cont){
		
		int pocion=20;
		int vitM=80;
		if (cont>0) {
		if(vitalidad+pocion<=vitM){
			this.vitalidad=this.vitalidad+pocion;
			System.out.println("Ha usado una poci�n, su vitalidad es de "+this.vitalidad);
		}else{
			System.out.println("Tiene la vida al completo");
		}
		cont--;		
		System.out.println("Te quedan "+cont+" pociones");
		}else{
			System.out.println("Te has quedado sin pociones");
		}
		return this.vitalidad;
	}
}
