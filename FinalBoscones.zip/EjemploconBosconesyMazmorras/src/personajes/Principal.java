package personajes;

import utilidades.Leer;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Tablero t1;

		int dano = 0;// Da�o que realiza el personaje

		String nombre = "";
		int min = 0;// Valor minimo del dado
		int max = 0;// Valor m�ximo del dado
		int tirada = 0;
		int vit1 = 0;// Vitalidad del jugador 1
		int vit2 = 0;// Vitalidad del jugador 2
		boolean ataque = false; // Booleano que controla si realiza el ataque
		boolean esquiva = false;// Booleano que controla si esquiva el ataque
		int agilidad1 = 0; // Agilidad del jugador 1
		int agilidad2 = 0; // Agilidad del jugador 2
		String nom1="";
		String nom2="";
		int cont1 = 0;
		int cont2=0;
		
		int opcion = 0;
		int opcion1 = 0;
		int opcion2 = 0;
		

		boolean disparo=false;
		Mago m1 = null;
		Mago m2 = null;
		Guerrero g1 = null;
		Guerrero g2 = null;
		Picaro p1 = null;
		Picaro p2 = null;
		Arquero a1=null;
		Arquero a2=null;
		min = 1;
		max = 20;
		cont1=3;
		cont2=3;
		int dren=10;
		boolean esp1=true;
		boolean esp2=true;
		
		Dado d1 = new Dado(min, max);
		t1 = new Tablero(d1);

		System.out.println("Jugador 1: introduzca el nombre de su personaje");
		nombre = Leer.dato();
		System.out.println("Escoja el tipo de personaje que desee");
		t1.mostrarSelectPersonaje();
		opcion1 = t1.controlarOpciones();

		switch (opcion1) {
		case 1:
			g1 = t1.crearPersonajeGuerrero(nombre);
			t1.mostrarPersonajeGuerrero(g1);
			agilidad1 = g1.getAgilidad();
			vit1 = g1.getVitalidad();
			nom1=g1.getNombre();
			break;
		case 2:
			m1 = t1.crearPersonajeMago(nombre);
			agilidad1 = m1.getAgilidad();
			t1.mostrarPersonajeMago(m1);
			vit1 = m1.getVitalidad();
			nom1=m1.getNombre();
			break;
		case 3:
			p1 = t1.crearPersonajePicaro(nombre);
			t1.mostrarPersonajePicaro(p1);
			agilidad1 = p1.getAgilidad();
			vit1 = p1.getVitalidad();
			nom1=p1.getNombre();
			break;
		case 4:
			a1 = t1.crearPersonajeArquero(nombre);
			t1.mostrarPersonajeArquero(a1);
			agilidad1 = a1.getAgilidad();
			vit1 = a1.getVitalidad();
			nom1=a1.getNombre();
			vit1 = a1.getVitalidad();
			break;
		}

		System.out.println("\nJugador 2: introduzca el nombre de su personaje");
		nombre = Leer.dato();
		t1.mostrarSelectPersonaje();
		opcion2 = t1.controlarOpciones();

		switch (opcion2) {
		case 1:
			g2 = t1.crearPersonajeGuerrero(nombre);
			t1.mostrarPersonajeGuerrero(g2);
			agilidad2 = g2.getAgilidad();
			vit2 = g2.getVitalidad();
			nom2=g2.getNombre();
			break;
		case 2:
			m2 = t1.crearPersonajeMago(nombre);
			t1.mostrarPersonajeMago(m2);
			agilidad2 = m2.getAgilidad();
			vit2 = m2.getVitalidad();
			nom2=m2.getNombre();
			break;
		case 3:
			p2 = t1.crearPersonajePicaro(nombre);
			t1.mostrarPersonajePicaro(p2);
			agilidad1 = p2.getAgilidad();
			vit2 = p2.getVitalidad();
			nom2=p2.getNombre();
			break;
		case 4:
			a2 = t1.crearPersonajeArquero(nombre);
			t1.mostrarPersonajeArquero(a2);
			agilidad2 = a2.getAgilidad();
			vit2 = a2.getVitalidad();
			nom2=a2.getNombre();
			vit2 = a2.getVitalidad();
			break;
		}

		do {
			System.out.println(nom1+" elige tu movimiento");
			switch (opcion1) {
			/**
			 * Caso del guerrero en jugador 1
			 */
			case 1:
				g1.mostrarAtaques();
				opcion = t1.controlarOpciones();
				
				switch (opcion) {
				case 1:
					tirada = d1.realizarTirada();
					System.out.printf(" de fuerza\n");
					ataque = t1.realizarAtaque(tirada, g1.getFuerza());
					tirada = d1.realizarTirada();
					System.out.printf(" de agilidad\n");

					esquiva = t1.esquivarAtaque(tirada, agilidad2);
					dano = g1.realizarFiloDevastador(ataque, esquiva);
					vit2 = vit2 - dano;
					
					t1.infringirDanyo(opcion2, g2, m2, p2, a2, dano);
					break;
				case 2:

					g1.realizarliberarArmadura(g1.getVitalidad());
					vit1=g1.getVitalidad();
					break;
				case 3:
					g1.usarPocion(g1.getVitalidad(), cont1);
					cont1--;
					vit1=g1.getVitalidad();
					break;
				case 4:
					tirada = d1.realizarTirada();
					System.out.printf(" de fuerza\n");
					ataque = t1.realizarAtaque(tirada, g1.getFuerza());
					tirada = d1.realizarTirada();
					System.out.printf(" de agilidad\n");

					esquiva = t1.esquivarAtaque(tirada, agilidad2);
					dano = g1.realizarEspadazo(ataque, esquiva, esp1);
					if(dano>0){
						esp1=false;
					}
					vit2 = vit2 - dano;

					t1.infringirDanyo(opcion2, g2, m2, p2, a2, dano);
					break;
				}
				break;

			case 2:
				/**
				 * Caso del Mago en jugador 1
				 */
				m1.mostrarAtaques();

				opcion = t1.controlarOpciones();
				switch (opcion) {
				case 1:
					tirada = d1.realizarTirada();
					System.out.printf(" de fuerza\n");
					ataque = t1.realizarAtaque(tirada, m1.getFuerza());
					tirada = d1.realizarTirada();
					System.out.printf(" de agilidad\n");

					esquiva = t1.esquivarAtaque(tirada, agilidad2);
					dano = m1.drenarVit(ataque, esquiva, vit1);
					vit2 = vit2 - dano;
					if (dano>0) {
						vit1=vit1+dren;
						m1.setVitalidad(vit1);
						System.out.println(nom1+" tu vitalidad es "+vit1);
					}
					
					t1.infringirDanyo(opcion2, g2, m2, p2, a2, dano);
					
					break;
				case 2:
					tirada = d1.realizarTirada();
					System.out.printf(" de fuerza\n");
					ataque = t1.realizarAtaque(tirada, m1.getFuerza());
					tirada = d1.realizarTirada();
					System.out.printf(" de agilidad\n");

					esquiva = t1.esquivarAtaque(tirada, agilidad2);
					dano = m1.electrocutarEnemigo(ataque, esquiva);
					
					vit2 = vit2 - dano;
					t1.infringirDanyo(opcion2, g2, m2, p2, a2, dano);
					
					
					break;
				case 3:
					vit1=m1.usarPocion(m1.getVitalidad(),cont1);
					cont1--;
					vit1=m1.getVitalidad();
					break;
				case 4:
					dano=m1.realizarSismo(ataque, esquiva, esp1);
					if(dano>0){
						esp1=false;
					}
					vit2 = vit2 - dano;
					t1.infringirDanyo(opcion2, g2, m2, p2, a2, dano);
					
					break;

				}
				break;

			case 3:
				

				/**
				 * Caso del Picaro en jugador 1
				 */
				p1.mostrarAtaques();
				
				opcion = t1.controlarOpciones();
				switch (opcion) {
				case 1:
					tirada = d1.realizarTirada();
					System.out.printf(" de fuerza\n");
					ataque = t1.realizarAtaque(tirada, p1.getFuerza());
					tirada = d1.realizarTirada();
					System.out.printf(" de agilidad\n");

					esquiva = t1.esquivarAtaque(tirada, agilidad2);
					dano = p1.realizarDagasExplosivas(ataque, esquiva);
					vit2 = vit2 - dano;
					t1.infringirDanyo(opcion2, g2, m2, p2, a2, dano);
					break;
				case 2:
					tirada = d1.realizarTirada();
					System.out.printf(" de fuerza\n");
					ataque = t1.realizarAtaque(tirada, p1.getFuerza());
					tirada = d1.realizarTirada();
					System.out.printf(" de agilidad\n");

					esquiva = t1.esquivarAtaque(tirada, agilidad2);
					dano = p1.realizarGolpeBajo(ataque, esquiva);
					vit2 = vit2 - dano;
					t1.infringirDanyo(opcion2, g2, m2, p2, a2, dano);
					break;
				case 3:
					vit1=m1.usarPocion(p1.getVitalidad(),cont1);
					cont1--;
					vit1=p1.getVitalidad();
					break;
				case 4:
					
					vit2 = vit2 - dano;
					t1.infringirDanyo(opcion2, g2, m2, p2, a2, dano);
					break;
					
					

				}
				
				break;
			case 4:
				/**
				 * Caso del Arquero en jugador 1
				 */
				a1.mostrarAtaques();
				
				
				opcion = t1.controlarOpciones();
				switch (opcion) {
				case 1:
					tirada = d1.realizarTirada();
					System.out.printf(" de fuerza\n");
					ataque = t1.realizarAtaque(tirada, a1.getFuerza());
					tirada = d1.realizarTirada();
					System.out.printf(" de agilidad\n");

					esquiva = t1.esquivarAtaque(tirada, agilidad2);
					dano = a1.disparoMultiple(ataque, esquiva, disparo);
					vit2 = vit2 - dano;
					t1.infringirDanyo(opcion2, g2, m2, p2, a2, dano);
					break;
					
				case 2:
					a1.afinarPunteria();
				case 3:
					vit1=m1.usarPocion(m1.getVitalidad(),cont1);
					cont1--;
					break;
				case 4:
					dano=a1.realizarFlechazo(ataque, esquiva, esp1);
					vit2 = vit2 - dano;
					t1.infringirDanyo(opcion2, g2, m2, p2, a2, dano);
					break;
					
				}
				break;
			}
			
			if (vit2 > 0) {

				System.out.println(nom2+" elige tu movimiento");
				switch (opcion2) {
				//Guerrero jugador2
				case 1:
					g2.mostrarAtaques();
					opcion = t1.controlarOpciones();
					switch (opcion) {
					case 1:
						tirada = d1.realizarTirada();
						System.out.printf(" de fuerza\n");
						ataque = t1.realizarAtaque(tirada, g2.getFuerza());
						tirada = d1.realizarTirada();
						System.out.printf(" de agilidad\n");

						esquiva = t1.esquivarAtaque(tirada, agilidad1);
						dano = g2.realizarFiloDevastador(ataque, esquiva);
						vit1 = vit1 - dano;
						t1.infringirDanyo(opcion1, g1, m1, p1, a1, dano);
						break;
						
					case 2:
							g2.realizarliberarArmadura(vit2);
							
							vit2=g2.getVitalidad();
						

						break;
					case 3:
						g2.usarPocion(g2.getVitalidad(),cont2);
						cont2--;
						vit2=g2.getVitalidad();
						break;
					case 4:
						tirada = d1.realizarTirada();
						System.out.printf(" de fuerza\n");
						ataque = t1.realizarAtaque(tirada, g2.getFuerza());
						tirada = d1.realizarTirada();
						System.out.printf(" de agilidad\n");

						esquiva = t1.esquivarAtaque(tirada, agilidad1);
						dano = g1.realizarEspadazo(ataque, esquiva, esp2);
						if(dano>0){
							esp2=false;
						}
						vit1 = vit1 - dano;

						t1.infringirDanyo(opcion1, g1, m1, p1, a1, dano);
						
						break;
					}
					break;
					//Mago jugador 2
				case 2:
					m2.mostrarAtaques();

					opcion = t1.controlarOpciones();
					switch (opcion) {
					case 1:
						tirada = d1.realizarTirada();
						System.out.printf(" de fuerza\n");
						ataque = t1.realizarAtaque(tirada, m2.getFuerza());
						tirada = d1.realizarTirada();
						System.out.printf(" de agilidad\n");

						esquiva = t1.esquivarAtaque(tirada, agilidad1);
						dano = m2.drenarVit(ataque, esquiva, vit2);
						
						vit1 = vit1 - dano;
						t1.infringirDanyo(opcion1, g1, m1, p1, a1, dano);
						break;
						
					case 2:
						tirada = d1.realizarTirada();
						System.out.printf(" de fuerza\n");
						ataque = t1.realizarAtaque(tirada, m2.getFuerza());
						tirada = d1.realizarTirada();
						System.out.printf(" de agilidad\n");

						esquiva = t1.esquivarAtaque(tirada, agilidad1);
						dano = m2.electrocutarEnemigo(ataque, esquiva);
						
						vit1 = vit1 - dano;
						t1.infringirDanyo(opcion1, g1, m1, p1, a1, dano);
						break;
						
					case 3:
						vit2=m2.usarPocion(m2.getVitalidad(),cont2);
						cont2--;
						vit2=m2.getVitalidad();
						break;
					case 4:
						dano=m1.realizarSismo(ataque, esquiva, esp1);
						if(dano>0){
							esp1=false;
						}
						vit1 = vit1 - dano;
						
						t1.infringirDanyo(opcion1, g1, m1, p1, a1, dano);
						break;
						
					}
					break;

				case 3:
					/*
					 * Picaro jugador 2
					 */
					p2.mostrarAtaques();
					opcion = t1.controlarOpciones();
					switch (opcion) {
					case 1:
						tirada = d1.realizarTirada();
						System.out.printf(" de fuerza\n");
						ataque = t1.realizarAtaque(tirada, p2.getFuerza());
						tirada = d1.realizarTirada();
						System.out.printf(" de agilidad\n");

						esquiva = t1.esquivarAtaque(tirada, agilidad1);
						
						dano = p2.realizarDagasExplosivas(ataque, esquiva);
						vit1 = vit1 - dano;
						t1.infringirDanyo(opcion2, g1, m1, p1, a1, dano);
						break;
						
					case 2:
						tirada = d1.realizarTirada();
						System.out.printf(" de fuerza\n");
						ataque = t1.realizarAtaque(tirada, p2.getFuerza());
						tirada = d1.realizarTirada();
						System.out.printf(" de agilidad\n");

						esquiva = t1.esquivarAtaque(tirada, agilidad1);
						dano = p2.realizarGolpeBajo(ataque, esquiva);
						vit1 = vit1 - dano;
						t1.infringirDanyo(opcion2, g1, m1, p1, a1, dano);
						break;
						
					case 3:
						vit2=p2.usarPocion(p2.getVitalidad(),cont2);
						cont2--;
						vit2=p2.getVitalidad();
						break;
					case 4:
						vit1 = vit1 - dano;
						t1.infringirDanyo(opcion2, g1, m1, p1, a1, dano);
						break;
						

					}
					
					break;
				case 4:
					
				/*
				 * Arquero jugador 2
				 */
				a2.mostrarAtaques();
				
				
				opcion = t1.controlarOpciones();
				switch (opcion) {
				case 1:
					tirada = d1.realizarTirada();
					System.out.printf(" de fuerza\n");
					ataque = t1.realizarAtaque(tirada, a2.getFuerza());
					tirada = d1.realizarTirada();
					System.out.printf(" de agilidad\n");

					esquiva = t1.esquivarAtaque(tirada, agilidad1);
					dano = a2.disparoMultiple(ataque, esquiva, disparo);
					vit1 = vit1 - dano;
					t1.infringirDanyo(opcion1, g1, m1, p1, a1, dano);
					
					break;
				case 2:
					a2.afinarPunteria();
				case 3:
					vit2=a2.usarPocion(a2.getVitalidad(),cont2);
					cont2--;
					vit2=a2.getVitalidad();
					break;
				case 4:
					
					dano=a2.realizarFlechazo(ataque, esquiva, esp2);
					vit1 = vit1 - dano;
					t1.infringirDanyo(opcion1, g1, m1, p1, a1, dano);
					break;
					
				}
				break;
				}
				if(vit1>0){
					System.out.println("La vitalidad de " +nom1+ " ahora es "
							+ vit1);
					
				}
				
				}
		} while (vit1 > 0 && vit2 > 0);

		if (vit2 <= 0) {
			System.out.println("Gana "+nom1);
		} else {
			System.out.println("Gana "+nom2);
		}
		
	}
}
