package personajes;

import utilidades.Leer;

public class GestionPartida {

	private Tablero t1;
	
	public GestionPartida(Tablero t1){
		this.t1=t1;
	}
	
	public int controlarOpciones(int opcion){
		opcion=Leer.datoInt();
		while (opcion< 1 || opcion > 4) {
			System.out
					.println("Opcion no disponible, por favor introduzca otro");
			opcion = Leer.datoInt();
		}
		return opcion;
	}
	
}
