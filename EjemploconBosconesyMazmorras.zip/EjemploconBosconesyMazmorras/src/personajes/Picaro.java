package personajes;

public class Picaro {
	
	//ATRIBUTOS
	
	private String nombre;
	private int vitalidad;
	private int agilidad;
	private int fuerza;

	
	//CONSTRUCTORES
	
	public Picaro() {
			
	}
	
	public Picaro(String nom, int fu, int vit, int ag){
		nombre=nom;
		fuerza=fu;
		vitalidad=vit;
		agilidad=ag;
	}
	
	//GETTINGS AND SETTINGS
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getFuerza() {
		return fuerza;
	}
	public void setFuerza(int fuerza) {
		this.fuerza = fuerza;
	}
	public int getVitalidad() {
		return vitalidad;
	}
	public void setVitalidad(int vitalidad) {
		this.vitalidad = vitalidad;
	}
	public int getAgilidad() {
		return agilidad;
	}
	public void setAgilidad(int agilidad) {
		this.agilidad = agilidad;
	}
	
	
	
	//ATAQUES
	
	public int realizarGolpeBajo(boolean ataque, boolean esquiva){
		
		int res=0;
		if (ataque == true && esquiva == false) {
			res = 20;
			System.out.println("�Golpe Bajo!\n");
		}else{
		System.out.println("El ataque ha fallado\n");
		}
		return res;
	
	}
	
	public int realizarDagasExplosivas(boolean ataque, boolean esquiva){
		int res=0;
		int tirada=0;
		
		int maximo=0;
		int minimo=0;
		
		maximo=20;
		minimo=1;
		Dado d1 = new Dado(maximo,minimo);
		
		
		
		if (ataque == true && esquiva == false) {
			res = 20;
			System.out.println("�Dagas explosivas!\n");
			tirada=d1.realizarTirada();
			System.out.println(" en dagas");
			if(tirada>=10){
				res=15;
			}
			
			if(tirada>=17 && tirada<=20){
				res=res+20;
				System.out.println("Da�o adicional");
			}
		}else{
		System.out.println("El ataque ha fallado\n");
		}
		
		
		
		return res;
	}
	
	
	
		
	public int recibirDanyo(boolean res, int danyo){
		if(res==true){
			this.vitalidad=this.vitalidad-danyo;
			
			System.out.printf("Ha recibido %.2f de da�o. Su vitalidad es"
					+ " de %.2f VIT", danyo,this.vitalidad);
		}
		return this.vitalidad;
	}
	
	
	
	public int usarPocion(int vitalidad, int cont){
		
		int pocion=20;
		int vitM=70;
		if (cont>0) {
		if(vitalidad+pocion<=vitM){
			this.vitalidad=this.vitalidad+pocion;
			System.out.println("Ha usado una poci�n, su vitalidad es de "+this.vitalidad);
		}else{
			System.out.println("Tiene la vida al completo");
		}
		cont--;		
		System.out.println("Te quedan "+cont+" pociones");
		}else{
			System.out.println("Te has quedado sin pociones");
		}
		return this.vitalidad;
	}
	public void mostrarDatosPersonaje() {
		System.out.println("Eres "+this.nombre+", un p�caro con "+
				((20-this.fuerza)*10)
				+ " de fuerza, con "+this.vitalidad+" de vitalidad y "+((20-this.agilidad)*10)+" de agilidad"
				);
	}
	public void mostrarAtaques(){
		System.out.println("\n\t1- Daga explosiva");
		System.out.println("\t2- Golpe Bajo");
		System.out.println("\t3- Usar Pocion");
		System.out.println("\t4- Golpe Umbrio\n");
		
	}
	/**Metodo para recibir da�o
	 * 
	 * @param danyo
	 * @return vitalidad Devuelve la vitalidad tras 
	 */
	public int recibirDanyo(int danyo) {

		this.vitalidad = this.vitalidad - danyo;

		System.out.printf("Ha recibido %d de da�o. Su vitalidad es"
				+ " de %d VIT\n", danyo, this.vitalidad);

		return this.vitalidad;
	}
	public int realizarGolpeUmbrio(boolean ataque, boolean esquiva, boolean esp) {
		int res = 0;
		
		if(esp==true){
		
		if (ataque == true && esquiva == false ) {
			res = 40;
			System.out.println("�Impacto Umbrio!\n");
			
		}else{
			System.out.println("El ataque ha fallado");
		}
		}else{
			System.out.println("Solo puedes usar el Impacto Umbrio una vez por partida.");
		}
		return res;
	}
}




