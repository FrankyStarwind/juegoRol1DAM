package personajes;
/**
 * 
 * 
 * @author Yafar
 * @version 1.0
 * @since 1.0
 */

public class Mago {

	//ATRIBUTOS
	
	private String nombre;
	private int vitalidad;
	private int agilidad;
	private int fuerza;

	
	//CONSTRUCTORES
	
	public Mago() {
		
	}
	/**
	 * 
	 * @param nombre Variable que guarda el nombre personalizado del usuario.
	 * @param fuerza guarda el valor de la fuerza del personaje que influye en la posibilidad
	 * de acertar el ataque
	 * @param vitalidad guarda el valor de la vitalidad del personaje que influye en la 
	 * vida del personaje
	 * @param agilidad guarda el valor de la agilidad del personaje que influye en
	 * la posibilidad de esquivar los ataques.
	 */

	public Mago(String nombre, int fuerza, int vitalidad, int agilidad) {
		
		this.nombre = nombre;
		this.vitalidad = vitalidad;
		this.agilidad = agilidad;
		this.fuerza = fuerza;
	}

	//GETTINGS AND SETTINGS
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getVitalidad() {
		return vitalidad;
	}

	public void setVitalidad(int vitalidad) {
		this.vitalidad = vitalidad;
	}

	public int getAgilidad() {
		return agilidad;
	}

	public void setAgilidad(int agilidad) {
		this.agilidad = agilidad;
	}

	public int getFuerza() {
		return fuerza;
	}

	public void setFuerza(int fuerza) {
		this.fuerza = fuerza;
	}
	
	//METODOS
	
	//He considerado que primero en el tablero se elije el ataque, entonces se tira dado de ataque y de esquiva, y esto es lo que se le
	//pasa al m�todo, el m�todo segun esto devuelve el ataque con su da�o y su cura o sino devuelve da�o 0 y en ambos casos un SYSO.
	
	/**
	 * Este m�todo es un ataque que drena vitalidad al contrincante, de tal forma que
	 * se le pasan, como a todos los ataques, los booleanos "Ataque" y "Esquiva", si
	 * los valores son los adecuados (true y false respectivamente) se realiza el ataque
	 * quitando "vit" al contrincante y dandoselo al mago.
	 * @param ataque recibe el booleano de la tirada de la clase dado.
	 * @param esquiva recibe el booleano de la tirada de la clase dado y da la posiblidad
	 * de esquivar el ataque, junto con la variable anterior decide si el ataque se realiza.
	 * @param vit variable de la vida del personaje.
	 * @return devuelve el da�o en caso de que ataque y esquiva sean los adecuados.
	 */

	
	public int drenarVit(boolean ataque, boolean esquiva, int vit){
		//Ataque es el tiro para acertar y esquiva para esquivar.
		int da�o=0;
		int vitdanyo=0;
		
		vitdanyo=10;
		if (ataque==true && esquiva==false ) {	
			if(vit<this.vitalidad){
				vit=vit+vitdanyo;
				this.vitalidad=vit;
				
			}
			System.out.println("�Has drenado a tu enemigo!");
			da�o=15;
			
		}else{
		System.out.println("El drenaje ha fallado.");	
		
		
		}
		return da�o;
	}
	/**
	 * Ataque simple que hace un da�o fijo de 30 puntos. Tiene que darse los valores adecuados
	 * de los boleanos Ataque y Esquiva.
	 * @param ataque recibe el booleano de la tirada de la clase dado.
	 * @param esquiva recibe el booleano de la tirada de la clase dado y da la posiblidad
	 * de esquivar el ataque, junto con la variable anterior decide si el ataque se realiza.
	 * @return devuelve el da�o en caso de que ataque y esquiva sean los adecuados.
	 */

	public int electrocutarEnemigo(boolean ataque, boolean esquiva){
		int da�o=0;
		if (ataque==true && esquiva==false) {
			System.out.println("!Has lanzado un rayo exterminador a tu enemigo!");
			da�o=30;
			
		}else{
			System.out.println("Electro ha fallado.");
			
		}
		return da�o;
	}
	/**
	 * M�todo que mustra los datos del nombe, vitalidad, fuerza y agilidad del personaje.
	 */

	
	public void mostrarDatosPersonaje() {
		System.out.println("Eres "+this.nombre+", un hechicero con "+
				((20-this.fuerza)*10)
				+ " de fuerza, con "+this.vitalidad+" de vitalidad y "+((20-this.agilidad)*10)+" de agilidad"
				);
	}
	/**
	 * Muestra los diferentes ataques del personaje para ser elegidos en el Switch
	 */

	public void mostrarAtaques(){
		System.out.println("\n\t1- Drenar");
		System.out.println("\t2- Electro");
		System.out.println("\t3- Usar Pocion");
		System.out.println("\t4- Sismo\n");
		
	}
	/**Metodo para recibir da�o
	 * 
	 * @param danyo variable que indica la cantidad de da�o que va a recibir el personaje.
	 * @return vitalidad Devuelve la vitalidad tras restar el da�o.
	 */

	public int recibirDanyo(int danyo) {

		this.vitalidad = this.vitalidad - danyo;

		System.out.printf("Ha recibido %d de da�o. Su vitalidad es"
				+ " de %d VIT\n", danyo, this.vitalidad);

		return this.vitalidad;
	}
	/**
	 * Ataque especial que quita m�s da�o del normal pero solo se puede usar una vez.
	 * @param ataque Variable proviniente de la clase dado que indica si la tirada ha sido
	 * suficiente.
	 * @param esquiva recibe el booleano de la tirada de la clase dado y da la posiblidad
	 * de esquivar el ataque, junto con la variable anterior decide si el ataque se realiza.
	 * @param esp boolean que controla si se ha usado alguna vez el ataque y no deja repetir.
	 * @return
	 */

	public int realizarSismo(boolean ataque, boolean esquiva, boolean esp) {
		int res = 0;
		
		if(esp==true){
		
		if (ataque == true && esquiva == false ) {
			res = 40;
			System.out.println("�Super Espadazo!\n");

			esp=false;	
		}else{
			System.out.println("El ataque ha fallado");
		}
		}else{
			System.out.println("Solo puedes usar el Sismo una vez por partida.");
		}
		return res;
	}
	/**
	 * Este m�todo usa las pociones, estas recuperar 20 puntos de vida (vit) del personaje
	 * y estan limitadas a 3 usos.
	 * @param vitalidad vitalidad actual del personaje.
	 * @param cont variable que controla la cantidad de pociones que se han usado. No permite
	 * m�s de tres.
	 * @return Devuelve la vitalidad despu�s de haberle sumado la poci�n.
	 */

	public int usarPocion(int vitalidad, int cont){
		
		int pocion=20;
		int vitM=80;
		if (cont>0) {
		if(vitalidad+pocion<=vitM){
			this.vitalidad=this.vitalidad+pocion;
			System.out.println("Ha usado una poci�n, su vitalidad es de "+this.vitalidad);
		}else{
			System.out.println("Tiene la vida al completo");
		}
		cont--;		
		System.out.println("Te quedan "+cont+" pociones");
		}else{
			System.out.println("Te has quedado sin pociones");
		}
		return this.vitalidad;
	}
}
