package personajes;
/**
 * La clase Dado nos permite realizar las tiradas para los comandos de atacar y esquivar.
 * @author fbustamante
 * 
 */
public class Dado {

	/**
	 * Atributo que permite definir el m�ximo del dado
	 */
	private int maximo;
	/**
	 * Atributo que permite definir el m�nimo del dado
	 */
	private int minimo;
	
	public Dado(){
		
	}
	public Dado(int max, int min){
		maximo=max;
		minimo=min;
	}
	/**
	 * M�todo que encarga de gestionar las tiradas de dado de los m�todos situados en todas las clases que las necesite.
	 * @return el n�mero aleatorio definido entre el m�ximo y el m�nimo
	 */
	public int realizarTirada() {
		int res = 0;
		res = (int) Math.floor(Math.random() * (this.maximo - this.minimo + 1) + this.minimo);

		System.out.printf("Ha salido "+res);
		return res;
	}
}
