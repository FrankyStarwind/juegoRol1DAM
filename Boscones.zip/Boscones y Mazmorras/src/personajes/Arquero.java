package personajes;

//ATRIBUTOS

public class Arquero {
	private String nombre;
	private int fuerza;
	private int vitalidad;
	private int agilidad;

	// CONSTRUCTORES

	public Arquero() {

	}

	public Arquero(String nombre, int fuerza, int vitalidad, int agilidad) {

		this.nombre = nombre;
		this.fuerza = fuerza;
		this.vitalidad = vitalidad;
		this.agilidad = agilidad;
	}

	// GETTERS AND SETTERS
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getFuerza() {
		return fuerza;
	}

	public void setFuerza(int fuerza) {
		this.fuerza = fuerza;
	}

	public int getVitalidad() {
		return vitalidad;
	}

	public void setVitalidad(int vitalidad) {
		this.vitalidad = vitalidad;
	}

	public int getAgilidad() {
		return agilidad;
	}

	public void setAgilidad(int agilidad) {
		this.agilidad = agilidad;
	}

	// M�TODOS
	// Realiza el ataque disparo m�ltiple del guerrero pasandole los
	// booleanos resultantes de los m�todos
	// esquivarAtaque y realizarAtaque.
	public int disparoMultiple(boolean ataque, boolean esquiva, boolean disparo,int cont) {
		int res = 0;
		int tirada = 0;
		int max = 20;
		int minimo = 1;
		
		if(disparo==false){
		
		Dado d1 = new Dado(max, minimo);
		if (ataque == true && esquiva == false) {
			res = 15;
			System.out.println("�Disparo m�ltiple!\n");
			
			
			tirada = d1.realizarTirada();
			System.out.println();
			if (tirada >= 17) {
				res = res + 15;
				System.out.println("�Otra m�s!\n");
			}
			if (tirada == 20) {
				res = res + 15;
				System.out.println("�Disparo cr�tico!\n");
			}
		}else{
			System.out.println("\nEl ataque ha fallado\n");
			
		}
		
		}
		else{
			if(cont==0){
				res=35;
				System.out.println("�Disparo m�ltiple afinado!\n");
				
			}else{
				System.out.println("No puedes afinar m�s, el ataque falla ~\n");
			}
			
			}
		
		return res;
	}
	
	public boolean afinarPunteria() {
			boolean res=false;
			System.out.println("Punteria afinada");
			res=true;
			
		return res;
			
	}

	// Mostrar los datos del Arquero
	public void mostrarDatosPersonaje() {
		System.out.println("Eres " + this.nombre + ", un arquero con "
				+ ((20 - this.fuerza) * 10) + " de fuerza, con "
				+ this.vitalidad + " de vitalidad y "
				+ ((20 - this.agilidad) * 10) + " de agilidad");
	}

	public int recibirDanyo(int danyo, String nom) {

		this.vitalidad = this.vitalidad - danyo;

		System.out.printf("Ha recibido %d de da�o. La vitalidad de "+nom+" es"
				+ " de %d VIT\n", danyo, this.vitalidad);

		return this.vitalidad;
	}
	public int usarPocion(int vitalidad, int cont){
		
		int pocion=20;
		int vitM=90;
		if (cont>0) {
		if(vitalidad+pocion<=vitM){
			this.vitalidad=this.vitalidad+pocion;
			System.out.println("Ha usado una poci�n, su vitalidad es de "+this.vitalidad);
		}else{
			System.out.println("Tiene la vida al completo");
		}
		cont--;		
		System.out.println("Te quedan "+cont+" pociones");
		}else{
			System.out.println("Te has quedado sin pociones");
		}
		return this.vitalidad;
	}
	public void mostrarAtaques(){
		System.out.println("\n\t1- Disparo m�ltiple");
		System.out.println("\t2- Afinar punter�a");
		System.out.println("\t3- Usar Pocion");
		System.out.println("\t4- Flecha divina\n");
		
	}
	public int realizarFlechazo(boolean ataque, boolean esquiva, boolean esp) {
		int res = 0;
		
		if(esp==true){
		
		if (ataque == true && esquiva == false ) {
			res = 40;
			System.out.println("�Flecha divina!\n");
			
		}else{
			System.out.println("El ataque ha fallado");
		}
		}else{
			System.out.println("Solo puedes usar la Flecha divina una vez por partida.");
		}
		return res;
	}
	public int gestionarTiros(boolean disp){
		int cont =0;
		if(disp==true){
			cont++;
		}
		return cont;
	}
	
}
