package personajes;
/**
 * Este es el arquero.
 * @author Alejandro �lvarez
 * @since JDK 1.7
 */

//ATRIBUTOS

public class Arquero {

	/** El nombre, atributo que define como se llama el personaje. */
	private String nombre;

	/** La fuerza, atributo que define el resultado m�nimo que necesita un ataque para realizarse. */
	private int fuerza;

	/** La vitalidad, atributo que define los puntos de vida del personaje. */
	private int vitalidad;

	/** La agilidad, atributo que define el resultado m�nimo que necesita un ataque para esquivarse. */
	private int agilidad;

	// CONSTRUCTORES

	public Arquero() {

	}

	public Arquero(String nombre, int fuerza, int vitalidad, int agilidad) {

		this.nombre = nombre;
		this.fuerza = fuerza;
		this.vitalidad = vitalidad;
		this.agilidad = agilidad;
	}

	// GETTERS AND SETTERS
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getFuerza() {
		return fuerza;
	}

	public void setFuerza(int fuerza) {
		this.fuerza = fuerza;
	}

	public int getVitalidad() {
		return vitalidad;
	}

	public void setVitalidad(int vitalidad) {
		this.vitalidad = vitalidad;
	}

	public int getAgilidad() {
		return agilidad;
	}

	public void setAgilidad(int agilidad) {
		this.agilidad = agilidad;
	}

	// M�TODOS

	/**
	 * Ataque que le quita al enemigo 15 de vida, si la tirada sale mayor o igual a 17
	 * vuelve a realizar el ataque, si es igual a 20 realiza un ataque cr�tico.
	 *
	 * @param ataque booleano que recibe de la clase {@link personajes.Tablero#realizarAtaque(int, int)}
	 * @param esquiva booleano que recibe de la clase {@link personajes.Tablero#esquivarAtaque(int, int)}
	 * @param disparo the disparo
	 * @param cont variable que se usa como contador del ataque.
	 * @return devuelve el da�o realizado al enemigo.
	 */
	public int disparoMultiple(boolean ataque, boolean esquiva, boolean disparo,int cont) {
		int res = 0;
		int tirada = 0;
		int max = 20;
		int minimo = 1;

		if(disparo==false){

			Dado d1 = new Dado(max, minimo);
			if (ataque == true && esquiva == false) {
				res = 15;
				System.out.println("�Disparo m�ltiple!\n");


				tirada = d1.realizarTirada();
				System.out.println();
				if (tirada >= 17) {
					res = res + 15;
					System.out.println("�Otra m�s!\n");
				}
				if (tirada == 20) {
					res = res + 15;
					System.out.println("�Disparo cr�tico!\n");
				}
			}else{
				System.out.println("\nEl ataque ha fallado\n");

			}

		}
		else{
			if(cont==0){
				res=35;
				System.out.println("�Disparo m�ltiple afinado!\n");

			}else{
				System.out.println("No puedes afinar m�s, el ataque falla ~\n");
			}

		}

		return res;
	}

	/**
	 * Permite afinar la punteria del arquero para que pueda realizar un cr�tico.
	 *
	 * @return devuelve un boleano
	 */
	public boolean afinarPunteria() {
		boolean res=false;
		System.out.println("Punteria afinada");
		res=true;

		return res;

	}


	/**
	 * Muestra los datos del arquero.
	 */
	public void mostrarDatosPersonaje() {
		System.out.println("Eres " + this.nombre + ", un arquero con "
				+ ((20 - this.fuerza) * 10) + " de fuerza, con "
				+ this.vitalidad + " de vitalidad y "
				+ ((20 - this.agilidad) * 10) + " de agilidad");
	}

	/**
	 * Da�o que recibe del enemigo.
	 *
	 * @param se le pasa una variable da�o.
	 * @param se le pasa una variable nombre.
	 * @return devuelve la vida con la que se queda el arquero despues de recibir un ataque de su enemigo.
	 */
	public int recibirDanyo(int danyo, String nom) {

		this.vitalidad = this.vitalidad - danyo;

		System.out.printf("Ha recibido %d de da�o. La vitalidad de "+nom+" es"
				+ " de %d VIT\n", danyo, this.vitalidad);

		return this.vitalidad;
	}
	/**
	 * Cura al personaje con una poci�n de 20 puntos de vitalidad. Si tiene la vida completa no aumenta.
	 * @param vitalidad.
	 * @return Devuelve la vitalidad tras el uso de la poci�n.
	 */
	public int usarPocion(int vitalidad, int cont){

		int pocion=20;
		int vitM=90;
		if (cont>0) {
			if(vitalidad+pocion<=vitM){
				this.vitalidad=this.vitalidad+pocion;
				System.out.println("Ha usado una poci�n, su vitalidad es de "+this.vitalidad);
			}else{
				System.out.println("Tiene la vida al completo");
			}
			cont--;		
			System.out.println("Te quedan "+cont+" pociones");
		}else{
			System.out.println("Te has quedado sin pociones");
		}
		return this.vitalidad;
	}

	/**
	 * Muestra los ataques disponibles de nuestro arquero.
	 */
	public void mostrarAtaques(){
		System.out.println("\n\t1- Disparo m�ltiple");
		System.out.println("\t2- Afinar punter�a");
		System.out.println("\t3- Usar Pocion");
		System.out.println("\t4- Flecha divina\n");

	}

	/**
	 * Realiza un ataque especial. S�lo puede usarse una vez por partida si acierta el golpe.
	 * @param ataque
	 * @param esquiva
	 * @return el da�o que realiza el ataque seg�n si ha realizado el ataque con �xito o no.
	 */
	public int realizarFlechazo(boolean ataque, boolean esquiva, boolean esp) {
		int res = 0;

		if(esp==true){

			if (ataque == true && esquiva == false ) {
				res = 40;
				System.out.println("�Flecha divina!\n");

			}else{
				System.out.println("El ataque ha fallado");
			}
		}else{
			System.out.println("Solo puedes usar la Flecha divina una vez por partida.");
		}
		return res;
	}

	/**
	 * Va almacenando el n�mero de tiros.
	 *
	 * @param disp 
	 * @return devuelve la cuenta de los tiros.
	 */
	public int gestionarTiros(boolean disp){
		int cont =0;
		if(disp==true){
			cont++;
		}
		return cont;
	}

}
