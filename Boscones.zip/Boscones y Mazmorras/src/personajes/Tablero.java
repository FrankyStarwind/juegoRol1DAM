package personajes;

import utilidades.Leer;
/**
 * 
 * @author fbustamante
 * @version 1.0
 */
public class Tablero {

	private Dado d1;

	public Tablero() {

	}

	public Tablero(Dado d1) {
		this.d1 = d1;
	}

	public Dado getD1() {
		return d1;
	}

	public void setD1(Dado d1) {
		this.d1 = d1;
	}
	/**
	 * Muestra un mensaje de bienvenida con instrucciones.
	 */
	public void introduccion(){
		int opcion=0;
		int condition=0;
		System.out.println("\t\t|\t\t\tBienvenido a Boscones y Mazmorras                       |");
		System.out.print("\t\t");
		for(int i=0; i<40;i++){
			System.out.print("--");
		}
		System.out.println("\n\n\n A continuaci�n podr�s"
				+ " elegir un personaje con el que pelear contra tu oponente. \n\n Todos los"
				+ " personajes tienen dos ataques propios y �nicos, uno especial, que solo pueden"
				+ " usar una vez en la partida, y 3 pociones\n que restauran 20 de vitalidad.\n\n"
				+ " Usar cualquier opci�n gastar� turno, se acierte o no. Para acertar"
				+ " se tirar� un dado de ataque, y el contrincante uno de esquiva.\n El valor"
				+ " necesario para esquivar o acertar depende de la fuerza y la agilidad de los"
				+ " personajes. �ADELANTE Y A POR LA VICTORIA! \n");
		while (condition!=1) {
			
			System.out.println("\n<-------------------------------------------------------------------------------->\n");
		System.out.println("A continuaci�n puede ver una explicaci�n de cada personaje. Para jugar pulse 5.\n\n1.Guerrero\n2.Mago\n3.P�caro\n4.Arquero\n5.Jugar");
		/**
		 * 
		 */
		opcion=Leer.datoInt();
		switch (opcion) {
		case 1:
			System.out.println("Guerrero: \nCuenta con el ataque Filo Devastador, es su ataque"
					+ " b�sico, si acierta inflinge 20 de da�o. Liberar Armadura sacrifica\n"
					+ " vitalidad a favor de obtener m�s fuerza y as� acertar mas facilmente"
					+ ", s�lo se usa una vez por batalla. Por �ltimo tiene\n Super Espadazo"
					+ " que es el ataque especial de este personaje.");
			break;
		case 2:
			System.out.println("Mago: \nDrenar inflinge 15 puntos de da�o y cura al mago 10."
					+ " Electro es su ataque b�sico. Y por �ltimo Sismo es su ataque especial.");
			break;
		case 3:
			System.out.println("P�caro: \nDaga Explosiva es un ataque que inflinge 20 de da�o"
					+ " adem�s se realiza una segunda tirada que requiere una puntuaci�n alta\n (17)"
					+ " y a�ade 20 putos mas de da�o sumando un total de 40. Golpe bajo es su"
					+ " ataque b�sico y Golpe Umbrio su ataque especial. ");
			
			break;
		case 4:
			System.out.println("Arquero: \nDisparo M�ltiple realiza varios ataques consecutivos"
					+ " pudiendo quitar una gran cantidad de vida al oponente pero necesita"
					+ " de\n una buena tirada. Afinar punter�a asegura 100% acierto en el"
					+ " pr�ximo ataque. Flecha Divina es su ataque especial.");
			
			break;
		case 5:
			condition=1;
			break;

		default:
			System.out.println("Escoja una opci�n correcta.");
			break;
		}
		}
	}
	/**
	 * Muestra las opciones para escoger personaje
	 */
	public void mostrarSelectPersonaje() {
		System.out.println("Seleccione un personaje");
		System.out.println("\t1-Guerrero");
		System.out.println("\t2-Mago");
		System.out.println("\t3-P�caro");
		System.out.println("\t4-Arquero\n");
		
	}
	
	/** M�todo para crear un guerrero
	 * 
	 * @param nom Pasa el nombre del usuario
	 * @return g Devuelve un guerrero
	 */
	public Guerrero crearPersonajeGuerrero(String nom) {
		Guerrero g;
		int fuerza = 0;
		int vit = 0;
		int agilidad = 0;

		fuerza = 9;
		agilidad = 14;
		vit = 120;

		g = new Guerrero(nom, fuerza, vit, agilidad);
		return g;
	}

	/** M�todo para crear un Mago
	 * 
	 * @param nom Pasa el nombre del usuario
	 * @return m Devuelve un mago
	 */
	public Mago crearPersonajeMago(String nom) {
		Mago m;
		int fuerza = 0;
		int vit = 0;
		int agilidad = 0;

		fuerza = 12;
		agilidad = 11;
		vit = 80;

		m = new Mago(nom, fuerza, vit, agilidad);
		return m;
	}
	/** M�todo para crear un P�caro
	 * 
	 * @param nom Pasa el nombre del usuario
	 * @return p Devuelve un p�caro
	 */
	public Picaro crearPersonajePicaro(String nom) {
		Picaro p;
		int fuerza = 0;
		int vit = 0;
		int agilidad = 0;

		fuerza = 10;
		agilidad = 8;
		vit = 70;

		p = new Picaro(nom, fuerza, vit, agilidad);
		return p;
	}
	/** M�todo para crear un Arquero
	 * 
	 * @param nom Pasa el nombre del usuario
	 * @return a Devuelve un arquero
	 */
	public Arquero crearPersonajeArquero(String nom) {
		Arquero a;
		int fuerza = 0;
		int vit = 0;
		int agilidad = 0;

		fuerza = 13;
		agilidad = 9;
		vit = 90;

		a = new Arquero(nom, fuerza, vit, agilidad);
		return a;
	}
	/**
	 * M�todo que muestra los datos del personaje llamando a {@link }
	 * @param g1
	 */
	public void mostrarPersonajeGuerrero(Guerrero g1) {
		g1.mostrarDatosPersonaje();
	}

	public void mostrarPersonajeMago(Mago m1) {
		m1.mostrarDatosPersonaje();
	}

	public void mostrarPersonajePicaro(Picaro picaro) {
		picaro.mostrarDatosPersonaje();
		
	}
	public void mostrarPersonajeArquero(Arquero a){
		a.mostrarDatosPersonaje();
	}
	/**
	 * 
	 * @param tirada Valor que le pasamos del m�todo Realizar tirada de una clase Dado
	 * @param fuerza Par�metro que recibe la fuerza del personaje mediante el get de la clase correspondiente
	 * @return La respuesta de realizar el ataque con �xito o no
	 */


	public boolean realizarAtaque(int tirada, int fuerza) {
		boolean res = false;
		if (tirada >= fuerza) {
			res = true;
		}
		return res;
	}
	/**
	 * 
	 * @param tirada Valor que le pasamos del m�todo Realizar tirada de una clase Dado
	 * @param fuerza Par�metro que recibe la agilidad del personaje mediante el get de la clase correspondiente
	 * @return La respuesta de esquivar el ataque con �xito o no
	 */


	public boolean esquivarAtaque(int tirada, int agilidad) {
		boolean res = false;
		if (tirada >= agilidad) {
			res = true;
		}
		return res;
	}

	
	public int controlarOpciones(){
		int opcion = Leer.datoInt();
		while (opcion< 1 || opcion > 4) {
			System.out
					.println("Opcion no disponible, por favor introduzca otro");
			opcion = Leer.datoInt();
		}
		return opcion;
	}
	public void infringirDanyo(int opcion, Guerrero g,Mago m,Picaro p,Arquero a , int dano, String nom){
		
		switch(opcion){
		case 1:
			g.recibirDanyo(dano,nom);
			break;
		case 2:
			m.recibirDanyo(dano,nom);
			break;
		case 3:
			p.recibirDanyo(dano,nom);
			break;
		case 4:
			a.recibirDanyo(dano,nom);
			break;
		}
		
		
	}
	
	
	
}
