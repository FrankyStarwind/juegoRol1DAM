package personajes;
/**
 * El p�caro del juego
 * @author AntonioEscudero
 * @version 1.0
 * @since 1.0
 */
public class Picaro {
/**
 * 	 
 */
	//ATRIBUTOS
	
	private String nombre;
	private int vitalidad;
	private int agilidad;
	private int fuerza;

	
	//CONSTRUCTORES
	
	public Picaro() {
			
	}
	
	/**
	 * 
	 * @param nom Variable que guarda el nombre personalizado del usuario.
	 * @param fu guarda el valor de la fuerza del personaje que influye en la posibilidad
	 * de acertar el ataque
	 * @param vit guarda el valor de la vitalidad del personaje que influye en la 
	 * vida del personaje
	 * @param ag guarda el valor de la agilidad del personaje que influye en
	 * la posibilidad de esquivar los ataques.
	 */
	
	public Picaro(String nom, int fu, int vit, int ag){
		nombre=nom;
		fuerza=fu;
		vitalidad=vit;
		agilidad=ag;
	}
	
	//GETTINGS AND SETTINGS
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getFuerza() {
		return fuerza;
	}
	public void setFuerza(int fuerza) {
		this.fuerza = fuerza;
	}
	public int getVitalidad() {
		return vitalidad;
	}
	public void setVitalidad(int vitalidad) {
		this.vitalidad = vitalidad;
	}
	public int getAgilidad() {
		return agilidad;
	}
	public void setAgilidad(int agilidad) {
		this.agilidad = agilidad;
	}
	
	
	
	//METODOS
	
	/**
	 * Este m�todo es un ataque simple que realiza 20 de da�o, de tal forma que
	 * se le pasan, como a todos los ataques, los booleanos "Ataque" y "Esquiva", si
	 * los valores son los adecuados (true y false respectivamente) se realiza el ataque
	 * quitando "vit" al contrincante y restandoselo al oponente.
	 * @param ataque recibe el booleano de la tirada de la clase dado.
	 * @param esquiva recibe el booleano de la tirada de la clase dado y da la posiblidad
	 * de esquivar el ataque, junto con la variable anterior decide si el ataque se realiza.
	 * @return devuelve el da�o en caso de que ataque y esquiva sean los adecuados.
	 */
	
	public int realizarGolpeBajo(boolean ataque, boolean esquiva){
		
		int res=0;
		if (ataque == true && esquiva == false) {
			res = 20;
			System.out.println("�Golpe Bajo!\n");
		}else{
		System.out.println("El ataque ha fallado\n");
		}
		return res;
	
	}
	
	/**
	 * Este m�todo es un ataque que realiza da�o. Si la tirada es mayor o igual a 10 realizar�a 15 de da�o, si 
	 * saca de 17 a 20 ambos incluidos realizaria 15 de da�o adicional.
	 * @param ataque recibe el booleano de la tirada de la clase dado.
	 * @param esquiva recibe el booleano de la tirada de la clase dado y da la posiblidad
	 * de esquivar el ataque, junto con la variable anterior decide si el ataque se realiza.
	 * @return devuelve el da�o en caso de que ataque y esquiva sean los adecuados.
	 */
	
	public int realizarDagasExplosivas(boolean ataque, boolean esquiva){
		int res=0;
		int tirada=0;
		
		int maximo=0;
		int minimo=0;
		
		maximo=20;
		minimo=1;
		Dado d1 = new Dado(maximo,minimo);
		
		
		
		if (ataque == true && esquiva == false) {
			res = 20;
			System.out.println("�Dagas explosivas!\n");
			tirada=d1.realizarTirada();
			System.out.println(" en dagas");
			if(tirada>=10){
				res=15;
			}
			
			if(tirada>=17 && tirada<=20){
				res=res+20;
				System.out.println("Da�o adicional");
			}
		}else{
		System.out.println("El ataque ha fallado\n");
		}
		
		
		
		return res;
	}

	/**Metodo para recibir da�o
	 * 
	 * @param danyo variable que indica la cantidad de da�o que va a recibir el personaje.
	 * @return vitalidad Devuelve la vitalidad tras restar el da�o.
	 */
		
	public int recibirDanyo(int danyo, String nom) {

		this.vitalidad = this.vitalidad - danyo;

		System.out.printf("Ha recibido %d de da�o. La vitalidad de "+nom+" es"
				+ " de %d VIT\n", danyo, this.vitalidad);

		return this.vitalidad;
	}
	
	/**
	 * Este m�todo usa las pociones, estas recuperar 20 puntos de vida (vit) del personaje
	 * y estan limitadas a 3 usos.
	 * @param vitalidad vitalidad actual del personaje.
	 * @param cont variable que controla la cantidad de pociones que se han usado. No permite
	 * m�s de tres.
	 * @return Devuelve la vitalidad despu�s de haberle sumado la poci�n.
	 */
	
	public int usarPocion(int vitalidad, int cont){
		
		int pocion=20;
		int vitM=70;
		if (cont>0) {
		if(vitalidad+pocion<=vitM){
			this.vitalidad=this.vitalidad+pocion;
			System.out.println("Ha usado una poci�n, su vitalidad es de "+this.vitalidad);
		}else{
			System.out.println("Tiene la vida al completo");
		}
		cont--;		
		System.out.println("Te quedan "+cont+" pociones");
		}else{
			System.out.println("Te has quedado sin pociones");
		}
		return this.vitalidad;
	}

	/**
	 * M�todo que mustra los datos del nombre, vitalidad, fuerza y agilidad del personaje.
	 */
	
	public void mostrarDatosPersonaje() {
		System.out.println("Eres "+this.nombre+", un p�caro con "+
				((20-this.fuerza)*10)
				+ " de fuerza, con "+this.vitalidad+" de vitalidad y "+((20-this.agilidad)*10)+" de agilidad"
				);
	}
	
	/**
	 * M�todo que mustra los ataques del personaje.
	 */
	
	public void mostrarAtaques(){
		System.out.println("\n\t1- Daga explosiva");
		System.out.println("\t2- Golpe Bajo");
		System.out.println("\t3- Usar Pocion");
		System.out.println("\t4- Golpe Umbrio\n");
		
	}
	
	/**Metodo para recibir da�o
	 * 
	 * @param danyo
	 * @return vitalidad Devuelve la vitalidad tras 
	 */
	
	public int recibirDanyo(int danyo) {

		this.vitalidad = this.vitalidad - danyo;

		System.out.printf("Ha recibido %d de da�o. Su vitalidad es"
				+ " de %d VIT\n", danyo, this.vitalidad);

		return this.vitalidad;
	}
	
	/**M�todo para realizar Golpe Umbrio 
	 * 
	 * Ataque simple que hace un da�o fijo de 40 puntos. Tiene que darse los valores adecuados
	 * de los boleanos Ataque y Esquiva.
	 * @param ataque recibe el booleano de la tirada de la clase dado.
	 * @param esquiva recibe el booleano de la tirada de la clase dado y da la posiblidad
	 * de esquivar el ataque, junto con la variable anterior decide si el ataque se realiza.
	 * @return devuelve el da�o en caso de que ataque y esquiva sean los adecuados.
	 */
	
	public int realizarGolpeUmbrio(boolean ataque, boolean esquiva, boolean esp) {
		int res = 0;
		
		if(esp==true){
		
		if (ataque == true && esquiva == false ) {
			res = 40;
			System.out.println("�Impacto Umbrio!\n");
			
		}else{
			System.out.println("El ataque ha fallado");
		}
		}else{
			System.out.println("Solo puedes usar el Impacto Umbrio una vez por partida.");
		}
		return res;
	}
}