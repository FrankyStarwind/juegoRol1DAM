package personajes;

public class Guerrero {

	private String nombre;
	private int fuerza;
	private int vitalidad;
	private int agilidad;
	
	public Guerrero(){
		
	}
}
