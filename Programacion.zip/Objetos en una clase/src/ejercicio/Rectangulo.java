package ejercicio;

public class Rectangulo {

	private Punto origen;
	private int ancho;
	private int alto;
	
	public Rectangulo(){
		origen= new Punto(0,0);
		ancho=0;
		alto=0;
	}
	public Rectangulo(Punto o, int an, int al){
		origen=o;
		ancho=an;
		alto=al;
	}
	public void desplazar(int dx, int dy){
		this.origen.desplazar(dx, dy);
	}
	public int calculaArea(){
		int area=0;
		area=ancho*alto;
		return area;
	}
}
