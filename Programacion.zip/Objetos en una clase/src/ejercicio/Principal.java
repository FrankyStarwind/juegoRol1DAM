package ejercicio;

public class Principal {

	Punto p1 = new Punto(2,3);
	
	Rectangulo r1= new Rectangulo(p1, 5,4);
	
	
	
}
