package ejercicio;

public class Punto {

	private int x;
	private int y;
	
	public Punto(){
		
	}
	public Punto(int x, int y){
		this.x=x;
		this.y=y;
	}
	public void desplazar(int dx, int dy){
		x+=dx;
		y+=dy;
	}
}
