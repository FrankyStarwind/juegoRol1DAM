package personajes;

public class Guerrero {

	private String nombre;
	private int fuerza;
	private int vitalidad;
	private int agilidad;
	
	public Guerrero(){
		
	}
	public Guerrero(String nom, int fu, int vit, int ag){
		nombre=nom;
		fuerza=fu;
		vitalidad=vit;
		agilidad=ag;
	}
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getFuerza() {
		return fuerza;
	}
	public void setFuerza(int fuerza) {
		this.fuerza = fuerza;
	}
	public int getVitalidad() {
		return vitalidad;
	}
	public void setVitalidad(int vitalidad) {
		this.vitalidad = vitalidad;
	}
	public int getAgilidad() {
		return agilidad;
	}
	public void setAgilidad(int agilidad) {
		this.agilidad = agilidad;
	}
	public boolean realizarliberarArmadura(){
		boolean res=false;
		int cont=0;
		int cantidadCoste=20;
		int redTirada=2;
		
		if(cont==0){
			this.vitalidad=this.vitalidad-cantidadCoste;
			this.fuerza=this.fuerza-redTirada;
			System.out.println("");
			
			res=true;
			
		}else{
			System.out.println("Solo puedes usarlo una vez por combate.");
		}
		return res;
	}
	public int realizarFiloDevastador(int tirada){
		int res=0;
		if(tirada>=fuerza){
			res=20;
			System.out.println("�Filo devastador!");
		}
		return res;
	}
	
	
	public int recibirDanyo(boolean res, int danyo){
		if(res==true){
			this.vitalidad=this.vitalidad-danyo;
			
			System.out.printf("Ha recibido %.2f de da�o. Su vitalidad es"
					+ " de %.2f VIT", danyo,this.vitalidad);
		}
		return this.vitalidad;
	}
	

}
