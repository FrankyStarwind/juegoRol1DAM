package personajes;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Tablero t1 = new Tablero();
		int min=1;
		int max=20;
		int resultado=0;
		
		resultado=t1.realizarTirada(min, max);
		System.out.println("El resultado es "+resultado);
	}

}
