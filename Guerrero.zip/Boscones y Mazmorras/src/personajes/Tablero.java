package personajes;

public class Tablero {

	private Guerrero g1;
	private int dado;
	private int maximo;
	
	public Tablero(){
		
	}
	public Tablero(Guerrero g1, int d, int max){
		
	}
	/*
	public Guerrero crearPersonajeGuerrero(String nom, int fuerza,int agilidad){
		g1= new Guerrero(nom,vit, fuerza,agilidad);		
		return g1;
	}*/
	public int realizarTirada(int min, int max){
		int res=0;
		res=(int)Math.floor(Math.random()*(max-min+1)+min);
		return res;
	}
	/*
	public boolean realizarMovimiento(){
		
		
	}
	*/
}
