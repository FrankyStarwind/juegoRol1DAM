package personajes;

public class Picaro {
	
	//ATRIBUTOS
	
	private String nombre;
	private int vitalidad;
	private int agilidad;
	private int fuerza;

	
	//CONSTRUCTORES
	
	public Picaro() {
			
	}
	
	public Picaro(String nom, int fu, int vit, int ag){
		nombre=nom;
		fuerza=fu;
		vitalidad=vit;
		agilidad=ag;
	}
	
	//GETTINGS AND SETTINGS
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getFuerza() {
		return fuerza;
	}
	public void setFuerza(int fuerza) {
		this.fuerza = fuerza;
	}
	public int getVitalidad() {
		return vitalidad;
	}
	public void setVitalidad(int vitalidad) {
		this.vitalidad = vitalidad;
	}
	public int getAgilidad() {
		return agilidad;
	}
	public void setAgilidad(int agilidad) {
		this.agilidad = agilidad;
	}
	
	
	
	//ATAQUES
	
	public boolean realizarDagaVenenosa(){
		
		boolean res=false;
		int cont=0;
		if(cont<5){
			res=true;
			cont++;
		}
		return res;
	}
	
	public int realizarDagasExplosivas(boolean ataque, boolean esquiva){
		int res=0;
		int tirada=0;
		int contador=5;
		int maximo=0;
		int minimo=0;
		
		maximo=20;
		minimo=1;
		Dado d1 = new Dado(maximo,minimo);
		
		
		tirada=d1.realizarTirada();
		
		if(tirada>=10 && tirada<=16){
			res=15;
		}
		
		if(tirada>=17 && tirada<=20){
			res=res+20;
		}
		if(realizarDagaVenenosa()==true && contador>0){
			res=res+5;
			contador--;
		}else{
			System.out.println("El efecto de la daga venenosa se ha pasado.");
		}
		return res;
	}
	
	
	
		
	public int recibirDanyo(boolean res, int danyo){
		if(res==true){
			this.vitalidad=this.vitalidad-danyo;
			
			System.out.printf("Ha recibido %.2f de da�o. Su vitalidad es"
					+ " de %.2f VIT", danyo,this.vitalidad);
		}
		return this.vitalidad;
	}
	
	
	public int usarPocion(int vitalidad){
		int cont = 3;
		int pocion=20;
		int vitM=70;
		if (cont>0) {
		if(vitalidad+pocion<=vitM){
			this.vitalidad=this.vitalidad+pocion;
			System.out.println("Ha usado una poci�n, su vitalidad es de "+this.vitalidad);
		}else{
			System.out.println("Tiene la vida al completo");
		}
		cont--;		
		System.out.println("Te quedan "+cont+" pociones");
		}
		return this.vitalidad;
	}
	public void mostrarDatosPersonaje() {
		System.out.println("Eres "+this.nombre+", un p�caro con "+
				((20-this.fuerza)*10)
				+ " de fuerza, con "+this.vitalidad+" de vitalidad y "+((20-this.agilidad)*10)+" de agilidad"
				);
	}
	public void mostrarAtaques(){
		System.out.println("\n\t1- Daga explosiva");
		System.out.println("\t2- Envenenar daga");
		System.out.println("\t3- Usar Pocion");
		System.out.println("\t4- Sismo\n");
		
	}
}




