package personajes;

import utilidades.Leer;
/**
 * 
 * @author fbustamante
 *
 */
public class Tablero {

	private Dado d1;

	public Tablero() {

	}

	public Tablero(Dado d1) {
		this.d1 = d1;
	}

	public Dado getD1() {
		return d1;
	}

	public void setD1(Dado d1) {
		this.d1 = d1;
	}

	public void mostrarSelectPersonaje() {
		System.out.println("Seleccione un personaje");
		System.out.println("\t1-Guerrero");
		System.out.println("\t2-Mago");
		System.out.println("\t3-P�caro");
		System.out.println("\t4-Arquero\n");
		
	}
	
	// M�todo para crear un guerrero
	public Guerrero crearPersonajeGuerrero(String nom) {
		Guerrero g1;
		int fuerza = 0;
		int vit = 0;
		int agilidad = 0;

		fuerza = 9;
		agilidad = 14;
		vit = 120;

		g1 = new Guerrero(nom, fuerza, vit, agilidad);
		return g1;
	}

	// M�todo para crear un guerrero
	public Mago crearPersonajeMago(String nom) {
		Mago m1;
		int fuerza = 0;
		int vit = 0;
		int agilidad = 0;

		fuerza = 12;
		agilidad = 11;
		vit = 80;

		m1 = new Mago(nom, fuerza, vit, agilidad);
		return m1;
	}

	public Picaro crearPersonajePicaro(String nom) {
		Picaro p1;
		int fuerza = 0;
		int vit = 0;
		int agilidad = 0;

		fuerza = 10;
		agilidad = 7;
		vit = 70;

		p1 = new Picaro(nom, fuerza, vit, agilidad);
		return p1;
	}
	public Arquero crearPersonajeArquero(String nom) {
		Arquero a1;
		int fuerza = 0;
		int vit = 0;
		int agilidad = 0;

		fuerza = 13;
		agilidad = 8;
		vit = 90;

		a1 = new Arquero(nom, fuerza, vit, agilidad);
		return a1;
	}
	public void mostrarPersonajeGuerrero(Guerrero g1) {
		g1.mostrarDatosPersonaje();
	}

	public void mostrarPersonajeMago(Mago m1) {
		m1.mostrarDatosPersonaje();
	}
	


	public boolean realizarAtaque(int tirada, int fuerza) {
		boolean res = false;
		if (tirada >= fuerza) {
			res = true;
		}
		return res;
	}

	public boolean esquivarAtaque(int tirada, int agilidad) {
		boolean res = false;
		if (tirada >= agilidad) {
			res = true;
		}
		return res;
	}

	public int recibirDanyoGuerrero(Guerrero g1, int danyo) {
		int res = 0;
		res = g1.recibirDanyo(danyo);
		return res;
	}
	public int controlarOpciones(int opcion){
		while(opcion<1||opcion>4){
			System.out.println("Opcion no disponible, por favor introduzca otro");
			opcion=Leer.datoInt();
		}
		return opcion;
	}
	/*
	public boolean pasarTurno(boolean turn) {
		boolean turno = false;
		if (turno == false) {
			turno = true;
		} else {
			turno = false;
		}
		return turno;
	}
	*/

	public void mostrarPersonajePicaro(Picaro picaro) {
		picaro.mostrarDatosPersonaje();
		
	}
	public void mostrarPersonajeArquero(Arquero a){
		a.mostrarDatosPersonaje();
	}
}
