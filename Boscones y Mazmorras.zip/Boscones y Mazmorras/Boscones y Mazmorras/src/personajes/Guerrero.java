package personajes;
/**
 * 
 * @author fbustamante
 * @version 1.0
 */
public class Guerrero {
/**
 * 
 */
	private String nombre;
	private int fuerza;
	private int vitalidad;
	private int agilidad;

	public Guerrero() {

	}

	public Guerrero(String nom, int fu, int vit, int ag) {
		nombre = nom;
		fuerza = fu;
		vitalidad = vit;
		agilidad = ag;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getFuerza() {
		return fuerza;
	}

	public void setFuerza(int fuerza) {
		this.fuerza = fuerza;
	}

	public int getVitalidad() {
		return vitalidad;
	}

	public void setVitalidad(int vitalidad) {
		this.vitalidad = vitalidad;
	}

	public int getAgilidad() {
		return agilidad;
	}

	public void setAgilidad(int agilidad) {
		this.agilidad = agilidad;
	}

	// Ataque de liberar armadura donde el Guerrero, a cambio de 20 de vit
	// aumenta el parametro de tiradas
	
	/**
	 * Aumenta la probabilidad de atacar a cambio de 20 de vit, pero s�lo puedes hacerlo <b>una vez</b>.
	 * @param vit La vitalidad del personaje
	 * @return 
	 */
	public boolean realizarliberarArmadura(int vit) {
		boolean res = false;
		int cont = 0;
		int cantidadCoste = 20;
		int redTirada = 2;

		if (cont == 0) {
			
				vit=vit- cantidadCoste;
				this.vitalidad=vit;
			
			this.fuerza = this.fuerza - redTirada;
			System.out.println("\nLiberaci�n de armadura activada");
			
			System.out.println("Ahora sus ataques se realizan con "+this.fuerza+" o m�s.");
			res = true;
			cont++;
		} else {
			System.out.println("Solo puedes usarlo una vez por combate.");
		}
		System.out.println();
		return res;
	}

	/**
	 * Realiza el ataque <b>Filo Devastador</b> si cumple la condici�n del ataque. Si acierta, realiza 20 de
	 * da�o y si falla hace 0 de da�o. 
	 * @param ataque
	 * @param esquiva
	 * @return El da�o que realiza el ataque
	 */
	public int realizarFiloDevastador(boolean ataque, boolean esquiva) {
		int res = 0;
		if (ataque == true && esquiva == false) {
			res = 20;
			System.out.println("�Filo devastador!\n");
		}else{
		System.out.println("El ataque ha fallado\n");
		}
		return res;
	}
	
	/**Metodo para recibir da�o
	 * 
	 * @param danyo
	 * @return vitalidad Devuelve la vitalidad tras 
	 */
	public int recibirDanyo(int danyo) {

		this.vitalidad = this.vitalidad - danyo;

		System.out.printf("Ha recibido %d de da�o. Su vitalidad es"
				+ " de %d VIT\n", danyo, this.vitalidad);

		return this.vitalidad;
	}
	/**
	 * Muestra los datos del personaje como si vieras la ficha de rol
	 */
	public void mostrarDatosPersonaje() {
		System.out.println("Eres " + this.nombre + ", un guerrero con "
				+ ((20 - this.fuerza) * 10) + " de fuerza, con "
				+ this.vitalidad + " de vitalidad y "
				+ ((20 - this.agilidad) * 10) + " de agilidad");
	}
	/**
	 * Muestra las opciones disponibles del personaje
	 */
	public void mostrarAtaques(){
		System.out.println("\n\t1- Filo Devastador");
		System.out.println("\t2- Liberar armadura");
		System.out.println("\t3- Pocion");
		System.out.println("\t4- Super espadazo\n");
		
	}
	/**
	 * Realiza un ataque especial. S�lo puede usarse una vez por partida si acierta el golpe.
	 * @param ataque
	 * @param esquiva
	 * @return
	 */
	public int realizarEspadazo(boolean ataque, boolean esquiva) {
		int res = 0;
		int cont=0;
		if(cont==0){
		
		if (ataque == true && esquiva == false ) {
			res = 40;
			System.out.println("�Super Espadazo!\n");
			
		}else{
			System.out.println("El ataque ha fallado");
		}
		cont++;
		}else{
			System.out.println("Solo puedes usar el Super Espadazo una vez por partida.");
		}
		return res;
	}
	/**
	 * Cura al personaje con una poci�n de 20 puntos de vitalidad. Si tiene la vida completa <b>no aumenta</b>.
	 * @param vitalidad
	 * @return
	 */
	public int usarPocion(int vitalidad){
		int cont = 3;
		int pocion=20;
		int vitM=120;
		if (cont>0) {
		if(vitalidad+pocion<=vitM){
			this.vitalidad=this.vitalidad+pocion;
			System.out.println("Ha usado una poci�n, su vitalidad es de "+this.vitalidad);
		}else{
			System.out.println("Tiene la vida al completo");
		}
		cont--;		
		System.out.println("Te quedan "+cont+" pociones");
		}
		return this.vitalidad;
	}
}
