package personajes;
/**
 * 
 * @author fbustamante
 *
 */
public class Dado {

	private int maximo;
	private int minimo;
	
	public Dado(){
		
	}
	public Dado(int max, int min){
		maximo=max;
		minimo=min;
	}
	public int realizarTirada() {
		int res = 0;
		res = (int) Math.floor(Math.random() * (this.maximo - this.minimo + 1) + this.minimo);

		System.out.printf("Ha salido "+res);
		return res;
	}
}
